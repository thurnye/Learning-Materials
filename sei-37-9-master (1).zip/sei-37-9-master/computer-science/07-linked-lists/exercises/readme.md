![](https://ga-dash.s3.amazonaws.com/production/assets/logo-9f88ae6c9c3871690e33280fcf557f33.png)

# Linked Lists Exercise

Complete the methods and classes defined in `LinkedList.js` according to the specifications in the comments. You can automatically test your progress by running `npm install` inside this folder to install the automated testing libraries, then run `npm test` to see if your functions pass the test cases.

> **Note:** The myGA module links out to CodePen for a code challenge for a linked list. **This exercise is the same as the one here.**
