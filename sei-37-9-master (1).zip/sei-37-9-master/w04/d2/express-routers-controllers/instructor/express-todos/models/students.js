
let students = [
    {studentid:"001", name:"mishal"},
    {studentid:"007", name: "jireh"},
    {studentid:"666", name: "nicole"},
    {studentid:"888", name: "jason"},
]

let teachers = []

module.exports = {
    students: students,
    plums: [],
    teachers: teachers,
}