To sync your code with Jim's latest commit, run the following two commands: 

`git fetch --all`
`git reset --hard origin/master`
