const mongoose = require('mongoose')
const Schema = mongoose.Schema;

const movieSchema = new Schema({
    //title: String,
    title: {
        type: String,
        default: "Pokemon",
    },
    releaseYear: Number,
    mpaaRating: String,
    // our movie will have an array of actors
    cast: [String], 
    nowShowing: Boolean,
}, {
    timestamps: true,
})

module.exports = mongoose.model('Movie', movieSchema)