const express = require('express')
const router = express.Router();
let moviesCtrl = require('../controllers/moviesCtrl.js')

router.get('/new', moviesCtrl.newMovie)
router.get('/all', moviesCtrl.allMovies)
router.post('/', moviesCtrl.create)
router.get('/:id', moviesCtrl.show)

module.exports = router;