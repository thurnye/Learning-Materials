let MovieModel = require('../models/movieModel.js')

async function create(req,res) {
    console.log(req.body)
    let nowShowingValue = "on"
    if (req.body.nowShowing == 'on') {
        nowShowingValue = true
    } else {
        nowShowingValue = false
    }
    try {
        await MovieModel.create({
            title: req.body.title,
            releaseYear: req.body.releaseYear,
            mpaaRating: req.body.mpaaRating,
            cast: req.body.cast.split(','),
            nowShowing: nowShowingValue,
        })
    } catch (err) {
        console.log(err)
        return res.send('there was an error')
    }
    res.redirect('/') // redirect the user back to localhost:300/
}

async function allMovies(req,res) {
    let results = await MovieModel.find()
    // inject results in to EJS 
    res.render('movies/allMovies.ejs', {results: results})
}
async function show(req,res) {
    console.log(req.params.id)
    let result = await MovieModel.findOne({_id: req.params.id})
    console.log(result)
    res.render('movies/show.ejs', {result:result})
}

function newMovie(req,res) {
    //res.send('here is your form:')
    res.render('movies/new.ejs')
}



module.exports = {
    newMovie: newMovie,
    create,
    allMovies,
    show:show,
}