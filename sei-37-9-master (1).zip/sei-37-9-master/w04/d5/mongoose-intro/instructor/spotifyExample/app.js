var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
require('./config/database.js') // run the db connection code

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);

let mongoose = require('mongoose')
let Schema = mongoose.Schema;
let albumSchema = new Schema({
  name: String,
  rating: Number,
  songs: [Schema.Types.ObjectId],
  //songs: [{type: Schema.Types.ObjectId, ref: 'Song'}]
})
let AlbumModel = mongoose.model('Album', albumSchema)

let songSchema = new Schema({
  name: String,
  length: Number,
  artist: String,
})
let SongModel = mongoose.model('Song', songSchema)

app.get('/form', function(req,res) {
  res.render('form.ejs')
})



// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
