

# DOM LAB PT. 2: DOM EVENTS LAB

## This Lab is a deliverable.

<br>Everybody loves choice! For this lab, You have not one, but <strong>TWO(!) possible options</strong> for the DOM EVENTS Lab:<br><br>

Please <strong>choose ONE</strong> of the following options to submit for your deliverable:
1. Do <a href="dom-practice-lab-2a/dom-practice-lab-2a.md">these two mini projects</a> (a "Click Counter", and a "Morse Code Translator") <strong>(this option is recommended for beginners)</strong>, or
1. Do <a href="dom-practice-lab-2b.md">Part #2 of the DOM LAB</a> you already started <strong>(this option is harder/more challenging/requires more advanced DOM manipulation)</strong>

Please submit either one of the above two options, by posting a link to your solution in the deliverables. You can submit both as well if you really want to!<br><br>

<hr>
