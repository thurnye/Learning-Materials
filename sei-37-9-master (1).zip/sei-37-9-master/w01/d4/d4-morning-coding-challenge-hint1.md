You can use the javascript prompt() function in this way to store user inputs in a variable:
```javascript
let playerOneGuess = prompt("Player one, please type rock paper or scissors")
let playerTwoGuess = prompt("Player two, please type rock paper or scissors")
```
