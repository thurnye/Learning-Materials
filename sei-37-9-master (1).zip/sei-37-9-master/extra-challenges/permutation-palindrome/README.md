# Permutation Palindrome

Write an efficient function thats check whether any permutation of an input string is a palindrome.

Assume the input string only contains lowercase letters.

Examples:

- "level" should return true
- "elvel" should return true
- "evecl" should return false
- "levec" should return false
