# Longest "Distinct Characters" Substring

Write a function that takes in a string, and returns the length of the longest substring with all distinct/unique characters. For example, for input "abcddab", the output is 4 as "abcd" is the longest substring with all distinct characters.

Example:

```javascript
// input:
let str = 'abababcdefababcdab'

// returns 6
```
