# In Place Reverse

Write a function that takes an array of characters and reverses the letters **in place**

Example:

```javascript
let chars = ['a', 'b', 'c', 'a', 'd']
// returns ['d', 'a', 'c', 'b', 'a']
```

**Do this without creating a new array**
