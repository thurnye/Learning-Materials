# This is an app to demonstrate a few key concepts:

1. example on how to setup CRUD in controller (JSON) and operate on database (model)
1. routing files - setup CRUD using the /api/modelName  pattern
1. simple model example with some validations
1. seeds file if anyone is interested in pre-loading data into their application
1. With test suite in case anyone is feeling adventurous :smile:
1. to get this update on your local machine, from master git pull upstream master (edited) 
