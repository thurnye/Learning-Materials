# Resources for P1
1. If you're making a card game, check out <a href="card-deck-css">the card deck css</a>
# Resources for P2
# Resources for P3
# Resources for P4
1. <a href="react-puppies-crud">A fully functional React CRUD app</a>
2. <a href="integration-testing--puppies-api">Just the backend for the above app + integration tests</a>
