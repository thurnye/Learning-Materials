<img src="https://i.imgur.com/Xuk86tL.jpg" width="900">

# Realtime Chat Lab

## Requirements

- This lab is a partner exercise.

- Using your knowledge from the previous lesson, build a realtime chat app that:
  - Displays a text `<input>` for the user's name.
  - Displays a `<textarea>` for the user to enter a message in.
  - Displays a button tied to a click event that sends the message, then clears the `<textarea>`.
  - Displays the chat messages, along with the user's name that sent it - as they are sent!

## Bonus

- Display a timestamp with each chat message.
- Add some style to that sucka.
