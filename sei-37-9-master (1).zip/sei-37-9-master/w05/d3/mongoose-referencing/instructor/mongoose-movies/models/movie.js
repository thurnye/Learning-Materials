const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const reviewSchema = new Schema({
  content: String,
  rating: {type: Number, min: 1, max: 5, default: 5}
}, {
  timestamps: true
});

const movieSchema = new Schema({
  title: {
    type: String,
    required: true
  },
  releaseYear: {
    type: Number,
    default: function () {
      return new Date().getFullYear();
    }
  },
  mpaaRating: String,
  nowShowing: { type: Boolean, default: false },
  reviews: [reviewSchema],
  // cast: [Schema.Types.ObjectId]
  // this is how we do referencing:
  // we are storing an array of objectids
  // representing actors (from our actors model)
  cast: [{
    type: Schema.Types.ObjectId, // <-- an id of an actor
    ref: 'Performer' // <-- only useful if we use populate later
  }]
}, {
  timestamps: true
});

module.exports = mongoose.model('Movie', movieSchema);