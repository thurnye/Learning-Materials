const Performer = require('../models/performer');
const Movie = require('../models/movie');

module.exports = {
  new: newPerformer,
  create,
  addToCast: addToCast,
};

// omgz our user is trying to add "jim carrey" or somebody to some movie. 
async function addToCast(req,res) {
  console.log("incoming form data", req.body)
  console.log("incoming movie URL parameter ", req.params.id)
  // 1. find the appopriate movie being sent as a URL PARAMETER in our FORM ACTION
  let thisMovie = await Movie.findById(req.params.id)
  // 2. add the incoming actor's id (from the FORM DATA ie req.body) to the movie's cast
  // So we can know okay.. this movie has these 10 performers, and these are their ID's.
  thisMovie.cast.push(req.body.performerId)
  await thisMovie.save()
  res.send('thank you for your submission')
}

function create(req, res) {
  // Need to "fix" date formatting to prevent day off by 1
  // This is due to the <input type="date"> returning the date
  // string in this format:  "YYYY-MM-DD"
  // https://stackoverflow.com/questions/7556591/is-the-javascript-date-object-always-one-day-off
  const s = req.body.born;
  req.body.born = `${s.substr(5, 2)}-${s.substr(8, 2)}-${s.substr(0, 4)}`;
  Performer.create(req.body, function (err, performer) {
    res.redirect('/performers/new');
  });
}

function newPerformer(req, res) {
  Performer.find({}, function (err, performers) {
    res.render('performers/new', {
      title: 'Add Performer',
      performers
    });
  })
}