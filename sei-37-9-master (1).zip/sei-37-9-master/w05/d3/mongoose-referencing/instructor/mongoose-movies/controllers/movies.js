const Movie = require('../models/movie');

module.exports = {
  index,
  show,
  new: newMovie,
  create
};

function index(req, res) {
  Movie.find({}, function(err, movies) {
    res.render('movies/index', { title: 'All Movies', movies });
  });
}

let PerformerModel = require('../models/performer')

//a working show function (using populate)
async function show(req, res) {
  // find this movie
  let myMovie = await Movie.findById(req.params.id)
  // convert id's into documents
  await myMovie.execPopulate('cast')
  // get all performers from DB
  let allPerformers = await PerformerModel.find();
  res.render('movies/show.ejs', {
    title: 'Movie Detail',
    movie: myMovie,
    performers: allPerformers,
  })
}

// // a working show function (not using populate)
// async function show(req,res) {
//   let myMovie = await Movie.findById(req.params.id)
//   // convert the cast from an array of id's into an array of
//   // actual actor documents
//   let realPeople = []
//   for (let c of myMovie.cast) {
//     let realPerson = await PerformerModel.findById(c)
//     realPeople.push(realPerson)
//   }
//   let performers = await PerformerModel.find()
//   res.render('movies/show.ejs', {
//     title: 'Movie Detail',
//     movie: myMovie,
//     performers: performers,
//     realPeople: realPeople
//   })
// }

// // a working show function (with callbacks):
// function show(req, res) {
//   Movie.findById(req.params.id)
//   .populate('cast').exec(function(err, movie) {
//     // PerformerModel.find({}).where('_id').nin(movie.cast) <-- Mongoose query builder
//     // Native MongoDB approach 
//     PerformerModel.find(
//      {_id: {$nin: movie.cast}},
//      function(err, performers) {
//        console.log(performers);
//        res.render('movies/show', {
//          title: 'Movie Detail', movie, performers
//        });
//      }
//    );
//   });
// }

function newMovie(req, res) {
  res.render('movies/new', { title: 'Add Movie' });
}

function create(req, res) {
  // convert nowShowing's checkbox of nothing or "on" to boolean
  req.body.nowShowing = !!req.body.nowShowing;
  for (let key in req.body) {
    if (req.body[key] === '') delete req.body[key];
  }
  const movie = new Movie(req.body);
  movie.save(function(err) {
    if (err) return res.redirect('/movies/new');
    console.log(movie);
    res.redirect('/movies');
  });
}
