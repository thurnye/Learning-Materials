const express = require('express');
const router = express.Router();
const moviesCtrl = require('../controllers/movies');
const performersCtrl = require('../controllers/performers')

router.get('/', moviesCtrl.index);
router.get('/new', moviesCtrl.new);
router.get('/:id', moviesCtrl.show);
router.post('/', moviesCtrl.create);
// this POST handler handles our <form action="/some/address">:
router.post('/:id/performers', performersCtrl.addToCast)
module.exports = router;
