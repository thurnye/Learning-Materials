const Movie = require('../models/movie');

module.exports = {
  index,
  show,
  new: newMovie,
  create,
  createReview: createReview,
};

async function createReview(req,res) {
  try {

    console.log(req.body)
    console.log(req.params.id)
    // step 1: find the appropriate movie?
    let movie = await Movie.findOne({_id: req.params.id})
    //let movie = await Movie.findById(req.params.id)
    console.log(movie)
    // step 2: put this review into the movie's "reviews" array
    let reviewObj = {
      content: req.body.content,
      rating: req.body.rating,
    }
    movie.reviews.push(reviewObj)
    await movie.save()
    res.redirect('/movies/' + movie.id)

  } catch(error) {

    console.log(error)
    res.send('something went wrong')
    //res.render('error.ejs', {message: "something went wrong", error: error})

  }
}

function index(req, res) {
  Movie.find({}, function(err, movies) {
    res.render('movies/index', { title: 'All Movies', movies });
  });
}

function show(req, res) {
  Movie.findById(req.params.id, function(err, movie) {
    res.render('movies/show', { title: 'Movie Detail', movie });
  });
}

function newMovie(req, res) {
  res.render('movies/new', { title: 'Add Movie' });
}

function create(req, res) {
  // convert nowShowing's checkbox of nothing or "on" to boolean
  req.body.nowShowing = !!req.body.nowShowing;
  // remove whitespace next to commas
  req.body.cast = req.body.cast.replace(/\s*,\s*/g, ',');
  // split if it's not an empty string
  if (req.body.cast) req.body.cast = req.body.cast.split(',');
  for (let key in req.body) {
    if (req.body[key] === '') delete req.body[key];
  }
  const movie = new Movie(req.body);
  movie.save(function(err) {
    // one way to handle errors
    if (err) return res.redirect('/movies/new');
    console.log(movie);
    // for now, redirect right back to new.ejs
    res.redirect('/movies');
  });
}
